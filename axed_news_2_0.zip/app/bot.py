import asyncio, contextlib, logging
from aiogram import Bot, Dispatcher
from aiogram.client.session.aiohttp import AiohttpSession
from app.config import get_settings
from app.logger import setup_logging
from app.handlers import start, admin, health
from app.scheduler import setup_scheduler

async def create_bot_dp():
    settings = get_settings()
    session = AiohttpSession(proxy=settings.PROXY_URL) if settings.PROXY_URL else None
    bot = Bot(token=settings.BOT_TOKEN, session=session, parse_mode="HTML")
    dp = Dispatcher()
    dp.include_router(start.router)
    dp.include_router(admin.router)
    dp.include_router(health.router)
    return bot, dp, settings

async def main():
    setup_logging()
    bot, dp, settings = await create_bot_dp()
    scheduler = await setup_scheduler(bot, settings)
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        with contextlib.suppress(Exception):
            scheduler.shutdown(wait=False)
            await bot.session.close()
