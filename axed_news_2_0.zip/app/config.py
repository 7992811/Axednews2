from pydantic import BaseModel, ValidationError
from dotenv import load_dotenv
import os

load_dotenv()

class Settings(BaseModel):
    BOT_TOKEN: str
    CHANNEL_ID: int
    ADMINS: list[int]
    TZ: str = "Europe/Berlin"
    PROXY_URL: str | None = None
    OPENAI_API_KEY: str | None = None
    OPENAI_MODEL: str = "gpt-4o-mini"
    LLM_TIMEOUT: int = 30
    FETCH_INTERVAL_SEC: int = 300  # 5 минут
    POST_MIN_INTERVAL_SEC: int = 60

def get_settings() -> Settings:
    raw_admins = os.getenv("ADMINS", "")
    admins = [int(x.strip()) for x in raw_admins.split(",") if x.strip()]
    data = dict(
        BOT_TOKEN=os.environ["BOT_TOKEN"],
        CHANNEL_ID=int(os.environ["CHANNEL_ID"]),
        ADMINS=admins,
        TZ=os.getenv("TZ","Europe/Berlin"),
        PROXY_URL=os.getenv("PROXY_URL"),
        OPENAI_API_KEY=os.getenv("OPENAI_API_KEY"),
        OPENAI_MODEL=os.getenv("OPENAI_MODEL","gpt-4o-mini"),
        LLM_TIMEOUT=int(os.getenv("LLM_TIMEOUT","30")),
        FETCH_INTERVAL_SEC=int(os.getenv("FETCH_INTERVAL_SEC","300")),
        POST_MIN_INTERVAL_SEC=int(os.getenv("POST_MIN_INTERVAL_SEC","60")),
    )
    try:
        return Settings(**data)
    except ValidationError as e:
        raise RuntimeError(f"Config error: {e}")
