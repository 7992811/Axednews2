from aiogram import Router, F
from aiogram.types import Message
from app.config import get_settings
from app.services.poster import send_post
from app.services.storage import add_post, add_feed, list_feeds
import time

router = Router()

def is_admin(uid: int) -> bool:
    return uid in set(get_settings().ADMINS)

@router.message(F.text.startswith("/post"))
async def post_now(message: Message):
    if not is_admin(message.from_user.id):
        return await message.answer("Только для админов.")
    text = message.text.removeprefix("/post").strip() or "Тестовый пост"
    await send_post(message.bot, get_settings().CHANNEL_ID, text=text)
    await message.answer("Отправлено ✅")

@router.message(F.text.startswith("/schedule"))
async def schedule(message: Message):
    if not is_admin(message.from_user.id):
        return await message.answer("Только для админов.")
    # /schedule 2025-11-02 10:30 Текст
    try:
        _, date_str, time_str, *rest = message.text.split(maxsplit=3)
        text = rest[0] if rest else "Запланированный пост"
        ts = int(time.mktime(time.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")))
        await add_post(text=text, at_ts=ts)
        await message.answer(f"Запланировано на {date_str} {time_str} ✅")
    except Exception:
        await message.answer("Формат: /schedule YYYY-MM-DD HH:MM Текст")

@router.message(F.text.startswith("/addfeed"))
async def addfeed(message: Message):
    if not is_admin(message.from_user.id):
        return await message.answer("Только для админов.")
    url = message.text.removeprefix("/addfeed").strip()
    if not url:
        return await message.answer("Укажите URL: /addfeed https://example.com/rss")
    await add_feed(url)
    await message.answer(f"Добавлен фид: {url} ✅")

@router.message(F.text=="/listfeeds")
async def listfeeds(message: Message):
    if not is_admin(message.from_user.id):
        return await message.answer("Только для админов.")
    feeds = await list_feeds()
    if not feeds:
        return await message.answer("Фидов пока нет. Добавьте через /addfeed <url>")
    text = "\n".join(f"- {u}" for u in feeds)
    await message.answer("Активные фиды:\n" + text)
