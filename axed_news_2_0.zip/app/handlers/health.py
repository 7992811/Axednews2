from aiogram import Router, F
from aiogram.types import Message
import sqlite3

router = Router()

@router.message(F.text=="/health")
async def health(message: Message):
    try:
        sqlite3.connect("data.sqlite").close()
        await message.answer("✅ OK: Бот работает, база доступна.")
    except Exception as e:
        await message.answer(f"⚠️ DB error: {e}")
