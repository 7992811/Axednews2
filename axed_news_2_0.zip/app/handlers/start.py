from aiogram import Router, F
from aiogram.types import Message

router = Router()

@router.message(F.text=="/start")
async def start(message: Message):
    await message.answer(
        "Axed News 2.0 запущен. Команды:\n"
        "/post <текст> — пост в канал\n"
        "/addfeed <url> — добавить RSS\n"
        "/listfeeds — список фидов\n"
        "/schedule YYYY-MM-DD HH:MM Текст — запланировать пост\n"
        "/health — проверка состояния"
    )
