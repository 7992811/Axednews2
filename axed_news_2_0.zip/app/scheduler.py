from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from app.services.storage import init_db, pop_due, list_new_entries, mark_seen, is_seen, add_post
from app.services.summarizer import summarize
from app.config import Settings
import time

DEFAULT_FEEDS = [
    "https://www.coindesk.com/arc/outboundfeeds/rss/",
    "https://www.investing.com/rss/news_25.rss",
    "https://www.reuters.com/finance/markets/rss",
]

async def setup_scheduler(bot, settings: Settings):
    await init_db()
    # добавить дефолтные фиды один раз (мягко)
    from app.services.storage import add_feed, list_feeds
    existing = await list_feeds()
    for url in DEFAULT_FEEDS:
        if url not in existing:
            await add_feed(url)

    scheduler = AsyncIOScheduler(timezone=settings.TZ)

    async def job_fetch_and_queue():
        now = int(time.time())
        buckets = await list_new_entries()
        for _, entries in buckets:
            for e in entries:
                if await is_seen(e["guid"]):
                    continue
                text = await summarize(e["title"], e["summary"])
                link = f"\n<a href='{e['link']}'>Источник</a>" if e["link"] else ""
                body = text + link
                await add_post(text=body, at_ts=now + settings.POST_MIN_INTERVAL_SEC)
                await mark_seen(e["guid"])

    async def job_publish():
        now = int(time.time())
        due = await pop_due(now)
        if due:
            from app.services.poster import send_post
            await send_post(bot, settings.CHANNEL_ID, text=due["text"], image_url=due["image_url"])

    scheduler.add_job(job_fetch_and_queue, trigger=IntervalTrigger(seconds=settings.FETCH_INTERVAL_SEC))
    scheduler.add_job(job_publish, trigger=IntervalTrigger(seconds=15))
    scheduler.start()
    return scheduler
