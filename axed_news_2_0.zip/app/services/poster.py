from aiogram import Bot

async def send_post(bot: Bot, channel_id: int, text: str, image_url: str | None = None):
    if image_url:
        await bot.send_photo(channel_id, image_url, caption=text)
    else:
        await bot.send_message(channel_id, text)
