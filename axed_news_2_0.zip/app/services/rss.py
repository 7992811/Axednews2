import feedparser, hashlib, time

def normalize_entry(e):
    title = getattr(e, "title", "").strip()
    link = getattr(e, "link", "").strip()
    summary = getattr(e, "summary", "")[:500].strip() if hasattr(e, "summary") else ""
    guid_seed = link or title or str(time.time())
    guid = hashlib.md5(guid_seed.encode("utf-8")).hexdigest()
    return {"title": title, "link": link, "summary": summary, "guid": guid}

def fetch_feed(url: str):
    parsed = feedparser.parse(url)
    entries = [normalize_entry(e) for e in parsed.entries[:10]]
    return entries
