import aiosqlite, time

DB_PATH = "data.sqlite"

CREATE_SQL = [
    """
    CREATE TABLE IF NOT EXISTS posts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      text TEXT NOT NULL,
      image_url TEXT,
      at_ts INTEGER NOT NULL
    );
    """
    ,
    """
    CREATE TABLE IF NOT EXISTS feeds(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      url TEXT NOT NULL UNIQUE
    );
    """
    ,
    """
    CREATE TABLE IF NOT EXISTS seen(
      guid TEXT PRIMARY KEY,
      created_ts INTEGER NOT NULL
    );
    """
]

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        for sql in CREATE_SQL:
            await db.execute(sql)
        await db.commit()

async def add_post(text: str, at_ts: int, image_url: str | None = None):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO posts(text,image_url,at_ts) VALUES(?,?,?)", (text, image_url, at_ts))
        await db.commit()

async def pop_due(now_ts: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT id,text,image_url FROM posts WHERE at_ts<=? ORDER BY at_ts LIMIT 1", (now_ts,))
        row = await cur.fetchone()
        if not row: return None
        await db.execute("DELETE FROM posts WHERE id=?", (row[0],))
        await db.commit()
        return dict(text=row[1], image_url=row[2])

async def add_feed(url: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO feeds(url) VALUES(?)", (url,))
        await db.commit()

async def list_feeds():
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT url FROM feeds ORDER BY id")
        return [r[0] for r in await cur.fetchall()]

async def list_new_entries():
    # returns (feed_url, entries[]) for all feeds
    import time
    from app.services.rss import fetch_feed
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT url FROM feeds ORDER BY id")
        feeds = [r[0] for r in await cur.fetchall()]
    items = []
    for url in feeds:
        try:
            entries = fetch_feed(url)
            items.append((url, entries))
        except Exception:
            continue
    return items

async def mark_seen(guid: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO seen(guid, created_ts) VALUES(?,?)", (guid, int(time.time())))
        await db.commit()

async def is_seen(guid: str) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT 1 FROM seen WHERE guid=? LIMIT 1", (guid,))
        row = await cur.fetchone()
        return row is not None
