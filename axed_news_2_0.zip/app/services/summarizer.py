from app.config import get_settings
import httpx, re

def simple_summarize(title: str, summary: str) -> str:
    text = summary or ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > 220:
        text = text[:200].rstrip() + "..."
    return f"<b>{title}</b>\n{text}" if title else text

async def summarize(title: str, summary: str) -> str:
    s = get_settings()
    if not s.OPENAI_API_KEY:
        return simple_summarize(title, summary)
    prompt = (
        "Суммаризируй новость в 1-2 строки, без воды. Выведи только текст."
        f"\n\nЗаголовок: {title}\nСниппет: {summary}"
    )
    headers = {"Authorization": f"Bearer {s.OPENAI_API_KEY}", "Content-Type": "application/json"}
    payload = {"model": s.OPENAI_MODEL, "messages":[{"role":"user","content": prompt}], "temperature": 0.2}
    try:
        async with httpx.AsyncClient(timeout=s.LLM_TIMEOUT) as client:
            r = await client.post("https://api.openai.com/v1/chat/completions", json=payload, headers=headers)
            r.raise_for_status()
            data = r.json()
            return data["choices"][0]["message"]["content"].strip()
    except Exception:
        return simple_summarize(title, summary)
